<?php
/*
Plugin Name: Edge Instagram Feed
Description: Plugin that adds Instagram feed functionality to our theme
Author: Edge Themes
Version: 1.0
*/
define('EDGEF_INSTAGRAM_FEED_VERSION', '1.0');

include_once 'load.php';